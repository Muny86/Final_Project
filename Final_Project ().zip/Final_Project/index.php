<!DOCTYPE html>
<html>
<head>
    
    <title> Email list</title>
 
    <style>
        .topbutton{
            padding:20px;
        }
        .message{
            background:lightgreen; 
 
        }
    </style>



</head>

<body>
<span class="topbutton">

<a href="./display.php">Display Email List</a> 
</span>
<h1>Add Email to List</h1>
    
    <form action="./addToEmail_List.php" method="POST"> 

        <label for="first_name">First Name</label>
        <input id="first_name" name="first_name" type="text" />

        
        <label for="last_name">Last Name</label>
        <input id="last_name" name="last_name" type="text" />


        <label for="email">Email</label>
        <input id="email" name="email" type="text" />
        <input type="submit" name="submit" value="Submit"/>
    </form>
    
    <p class="message">Email added</p>

<script>
     
</script>
     
</body>


 

    
 
</html>