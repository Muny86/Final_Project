<!DOCTYPE html>
<html lang="en">
<head>
    <title>Display Email list</title>
    <style>

    td{
        width:100px;
    }
    </style>

</head>
<body>
<?php
//Get variables needed for connection
require_once("variables.php");
$query = "SELECT * FROM email_list";
$database = mysqli_connect(localhost, root, "", Email_List) or die("Connection error");
$result=mysqli_query($database, $query) or die('Database error.');



print ("<h1>Email list</h1>");
	print ("<table>");
	print ("<tr><td><b>First Name</b></td>");
	print ("<td><b>Last Name</b></td>");
	print ("<td><b>Email</b></td></tr>");
    
    while ($each = mysqli_fetch_array($result,MYSQLI_ASSOC)) {
        extract($each);      //Extract variables to variables names named the same as in the form
        
        print ("<tr><td>$first_name</td>");
        print ("<td>$last_name</td>");
        print ("<td>$email</td></tr>");
      

    }
	print ("</table>");
 
    
    mysqli_close($database);
?>
</body>
</html>
