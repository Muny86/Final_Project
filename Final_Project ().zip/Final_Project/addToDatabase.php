<?php
     
//Run this section if there was a post action Only
 
if(isset($_POST["submit"])){
    
    //First of all get variables for database connection
    require_once("variables.php");
        
    //Database Connection
    $database = mysqli_connect(localhost, root, "", Email_List) or die("Connection error");

    $firstName=$_POST["first_name"];
    $lastName=$_POST["last_name"];
    $email=$_POST["email"];

    // Add to the database table
    $query="INSERT INTO email_list (first_name,last_name,email) VALUES ('$firstName','$lastName','$email');";
    mysqli_query($database, $query) or die('Database error');
    mysqli_close($database); 
    
    header("Location: ./index.php");//Redirect back to index
}

 
    
 