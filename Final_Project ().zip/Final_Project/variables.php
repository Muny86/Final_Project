<?php

define("HOST", "127.0.0.1"); //Host IP
define("USER", "root");      //Username
define("PASSWORD", "");   //Password
define("DATABASE", "Email_List"); //Database name here